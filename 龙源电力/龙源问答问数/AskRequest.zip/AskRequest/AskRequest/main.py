import AskRequests
import concurrent.futures
import atexit
import signal
import pandas as pd
import AskThreadNew

#初始化数据
AskQuestion = AskThreadNew.AskRequsets()
#执行结果
AskQuestion.getResult()

